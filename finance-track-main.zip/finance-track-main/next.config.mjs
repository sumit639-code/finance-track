/** @type {import('next').NextConfig} */
const nextConfig = {
    pageExtensions: ['js', 'jsx']
};

export default nextConfig;
