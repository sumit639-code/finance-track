export default {
  schema: "./Utils/schema.jsx",
  dialect: "postgresql",
  dbCredentials: {
    url: 'postgresql://finance_owner:2DomrlXT4Sgw@ep-lingering-haze-a5nv8a7x.us-east-2.aws.neon.tech/finance?sslmode=require',
  },
};
